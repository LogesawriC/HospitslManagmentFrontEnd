import { Component } from '@angular/core';

@Component({
  selector: 'app-loginas',
  templateUrl: './loginas.component.html',
  styleUrls: ['./loginas.component.css']
})
export class LoginasComponent {

}
