import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Pharmacist } from 'src/app/service/pharmacist';
import { PharmacistService } from 'src/app/service/pharmacist.service';

@Component({
  selector: 'app-create-pharmacist',
  templateUrl: './create-pharmacist.component.html',
  styleUrls: ['./create-pharmacist.component.css']
})
export class CreatePharmacistComponent implements OnInit {

  pharmacist: Pharmacist = new Pharmacist();

  constructor(private pharmacistService: PharmacistService, private router: Router) {}

  ngOnInit(): void {
    // Initialization logic, if needed, can be added here.
  }

  savePharmacist() {
    this.pharmacistService.createPharmacist(this.pharmacist).subscribe(
      data => {
        console.log(data);
        this.goToPharmacistList();
      },
      error => console.error(error)
    );
  }

  goToPharmacistList() {
    this.router.navigate(['/pharmacists']);
  }

  onSubmit() {
    console.log(this.pharmacist);
    this.savePharmacist();
  }
}
