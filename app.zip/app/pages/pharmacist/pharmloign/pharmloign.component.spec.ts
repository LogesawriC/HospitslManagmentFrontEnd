import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PharmloignComponent } from './pharmloign.component';

describe('PharmloignComponent', () => {
  let component: PharmloignComponent;
  let fixture: ComponentFixture<PharmloignComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PharmloignComponent]
    });
    fixture = TestBed.createComponent(PharmloignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
