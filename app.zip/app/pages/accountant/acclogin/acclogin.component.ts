import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccauthService } from 'src/app/service/accauth.service';
import { AccountantService } from 'src/app/service/accountant.service';

@Component({
  selector: 'app-acclogin',
  templateUrl: './acclogin.component.html',
  styleUrls: ['./acclogin.component.css']
})
export class AccloginComponent {
  username: string = '';
  password: string = '';

  constructor(private router: Router) { }

  login() {
    // For demonstration purposes, let's set the demo user and password.
    const demoUser = 'accountant';
    const demoPassword = '12345';

    if (this.username.trim() === demoUser && this.password.trim() === demoPassword) {
      // Navigate to the accountant list page if the login is successful.
      this.router.navigate(['/accountant-list']);
    } else {
      alert('Invalid credentials. Please enter the correct username and password.');
    }
  }
}