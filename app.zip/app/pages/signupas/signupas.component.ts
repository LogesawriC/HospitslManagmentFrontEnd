import { Component } from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';

@Component({
  selector: 'app-signupas',
  templateUrl: './signupas.component.html',
  styleUrls: ['./signupas.component.css'],
  standalone: true,
  imports: [MatGridListModule],
})
export class SignupasComponent {

}
