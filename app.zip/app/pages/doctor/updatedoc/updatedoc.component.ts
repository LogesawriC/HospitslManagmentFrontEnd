import { Component } from '@angular/core';

@Component({
  selector: 'app-updatedoc',
  templateUrl: './updatedoc.component.html',
  styleUrls: ['./updatedoc.component.css']
})
export class UpdatedocComponent {
doctor: any;
formSubmit() {
throw new Error('Method not implemented.');
}


}
