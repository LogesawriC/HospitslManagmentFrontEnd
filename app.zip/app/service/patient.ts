export class Patient{

    id!: number;
    firstname!: string;
    lastname!: String;
    email!: string;
    username!: string;
    password!: string;
    address!: string;
    contact!: number;
    age!: number;
    gender!: string;
    bloodgroup!: string;
    testname!: string;
    doctorname!: string;
}

