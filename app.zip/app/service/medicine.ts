export class Medicine {
    id!: number;
    medicineName!: string;
    batchNumber!: string;
    manufactureDate!: Date;
    expiryDate!: Date;
    stock!: number;
  }
  