export class Invoice {
    id!:number;
    invoiceNumber!:String;
    amount!:number;
    date!:number;
    description!:string;
    accountantId!:number;

}

