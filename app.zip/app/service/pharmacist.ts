export class Pharmacist {
   

    id!:number;
    name!:string;
    userName!:string;
    password!:string;
    
}
