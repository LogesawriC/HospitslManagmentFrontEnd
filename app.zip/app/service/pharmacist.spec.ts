import { Pharmacist } from './pharmacist';

describe('Pharmacist', () => {
  it('should create an instance', () => {
    expect(new Pharmacist()).toBeTruthy();
  });
});
