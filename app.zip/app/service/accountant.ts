export class Accountant {
    id!:number;
    accountantName!:String;
    email!: String;
    username!:string;
    password!:string;


}
