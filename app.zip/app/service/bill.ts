export class Bill {
    id!:number;
    billNumber!:string;
    amount!:number;
    date!:Date;
    description!:string;
    accountantId!:number;
    }
    
    